#ifndef usuario_H_
#define usuario_H_
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "menu.h"
#include "configuracion.h"

typedef struct
{
	char nick[50];
	char nombre[50];
	int nivel;	
	int vida;
	int escudo;
	char estado[5];
	int dinero;
	int pjugadas;
	int pganadas;
	char perfil[4];
	char contrasenia[6];	
}usuario;

int nusuarios;

int iniciar_sesion(usuario **u);

void cargar_usuarios(usuario **u);

void guardar_usuarios(usuario *u);

void ver_perfil(usuario *u,int i);

void lista_usuarios (usuario *u);

void lista_usuarios_on(usuario *u);

#endif