#include "usuario.h"

void cargar_usuarios(usuario **u);
void guardar_usuarios(usuario *u);
void crear_usuario(usuario **u);
int iniciar_sesion(usuario **u);
int confirmar_usuario(usuario *u,char *user);
void crear_usuario(usuario **u,configuracion *c);
void ver_perfil(usuario *u,int i);
void lista_usuarios (usuario *u);
void lista_usuarios_on(usuario *u);

void cargar_usuarios(usuario **u){
	char cadena[100];
	char *ptr;
	char *delim="/";
	FILE *f;
	nusuarios=0;
	if(filexists("usuario.txt")==0){
		f=fopen("usuarios.txt","r+");
		fflush(stdin);
		while(fgets(cadena,100,f)!=NULL)
		{
			fixstring(cadena);
			*u=(usuario* )realloc((*u),(nusuarios+1)*sizeof(usuario));
			nusuarios++;
			ptr=strtok(cadena,delim);
			strcpy((*u)[nusuarios-1].nick,ptr);
			ptr=strtok(NULL,delim);
			strcpy((*u)[nusuarios-1].nombre,ptr);
			ptr=strtok(NULL,delim);
			(*u)[nusuarios-1].nivel=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*u)[nusuarios-1].vida=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*u)[nusuarios-1].escudo=atoi(ptr);
			ptr=strtok(NULL,delim);
			strcpy((*u)[nusuarios-1].estado,ptr);
			ptr=strtok(NULL,delim);
			(*u)[nusuarios-1].dinero=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*u)[nusuarios-1].pjugadas=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*u)[nusuarios-1].pganadas=atoi(ptr);
			ptr=strtok(NULL,delim);
			strcpy((*u)[nusuarios-1].perfil,ptr);
			ptr=strtok(NULL,delim);
			strcpy((*u)[nusuarios-1].contrasenia,ptr);
		}
		fclose(f);
	}
}

void guardar_usuarios(usuario *u){
	FILE *f;
	int i;
	f=fopen("usuarios.txt","w+");
	for(i=0;i<nusuarios;i++){
		fprintf(f,"%s/%s/%i/%i/%i/%s/",u[i].nick,u[i].nombre,u[i].nivel,u[i].vida,u[i].escudo,u[i].estado);
		fprintf(f, "%i/%i/%i/%s/%s\n",u[i].dinero,u[i].pjugadas,u[i].pganadas,u[i].perfil,u[i].contrasenia);
	}
	fclose(f);
}

int iniciar_sesion(usuario **u){
	char user[50];
	char pass[6];
	int i,res,iuser;
	char op;
	printf(" Introduce usuario: ");
	fflush(stdin);
	fgets(user,50,stdin);
	fixstring(user);
	i=confirmar_usuario(*u,user);
	if(i!=-1){
		do{
			printf("\n Introduce contrasenia: ");
			fflush(stdin);
			fgets(pass,50,stdin);
			fixstring(pass);
			res=strcmp(pass,(*u)[i].contrasenia);
			system("cls");
			if(res!=0){
				printf(" Contrasenia incorrecta\n Volver a intentar?(s/n): ");
				scanf("%s",&op);
			}
		}while(op=='n'||res!=0);
		if(op=='n') i=-1;
		if(res==0){
			strcpy((*u)[i].estado,"ON");
		}
	}
	else{
		printf(" Usuario introducido no existe\n Crear Nuevo Usuario?(s/n): \n");
		scanf("%s",&op);
		if(op=='s'){
			crear_usuario(&(*u));
		}
		i=-1;
	}
	return i;
}

int confirmar_usuario(usuario *u,char *usuario){
	int i;
	for(i=0;i<nusuarios;i++){
		if(strcmp(u[i].nick,usuario)==0){
			return i;
		}
	}
	return -1;
}


void crear_usuario(usuario **u,configuracion *c){
	char cadena[60];
	*u=(usuario* )realloc((*u),(nusuarios+1)*sizeof(usuario));
	nusuarios++;
	printf(" |Crear Usuario|\n");

	printf(" Nick: ");
	fflush(stdin);
	fgets(cadena,60,stdin);
	fixstring(cadena);
	strcpy((*u)[nusuarios-1].nick,cadena);

	printf(" Nombre Completo: ");
	fflush(stdin);
	fgets(cadena,60,stdin);
	fixstring(cadena);
	strcpy((*u)[nusuarios-1].nombre,cadena);

	(*u)[nusuarios-1].nivel=1;
	(*u)[nusuarios-1].vida=100;
	(*u)[nusuarios-1].escudo=0;
	strcpy((*u)[nusuarios-1].estado,"OFF");
	(*u)[nusuarios-1].dinero=100;
	(*u)[nusuarios-1].pjugadas=0;
	(*u)[nusuarios-1].pganadas=0;

	strcpy((*u)[nusuarios-1].perfil,"JGD");

	printf(" contrasena: ");
	fflush(stdin);
	fgets(cadena,60,stdin);
	fixstring(cadena);
	strcpy((*u)[nusuarios-1].contrasenia,cadena);
}

void ver_perfil(usuario *u,int i){
	printf(" |%s|\n",u[i].nick);
	printf(" Nombre: %s\n",u[i].nombre);
	printf(" Nivel: %d\n",u[i].nivel);
	printf(" Dinero: %d\n",u[i].dinero);
	printf(" Partidas Jugadas: %d\n",u[i].pjugadas);
	printf(" Partidas Ganadas: %d\n",u[i].pganadas);
	system("pause");
	system("cls");
}

void lista_usuarios (usuario *u){
	int i;
	printf("\t| LISTA USUARIOS |\n");
	printf(" | NICK | NOMBRE | NIVEL | VIDA | ESCUDO | ESTADO | DINERO | P.JUG | P.GAN | PERFIL | CONTRASENIA |\n");
	for(i = 0;i < nusuarios;i++){
		printf(" %s - %s - %i - %i - %i - |%s| -",u[i].nick,u[i].nombre,u[i].nivel,u[i].vida,u[i].escudo,u[i].estado);
		printf(" %i - %i - %i - %s - %s\n",u[i].dinero,u[i].pjugadas,u[i].pganadas,u[i].perfil,u[i].contrasenia);
		printf(" --------------------------------------------------------------------------------------------------\n");
	}
	system("pause");
	system("cls");
}

void lista_usuarios_on(usuario *u){
	int i;
	printf("\t| LISTA USUARIOS |\n");
	printf(" | NICK | NOMBRE | NIVEL | VIDA | ESCUDO | ESTADO | DINERO | P.JUG | P.GAN | PERFIL | CONTRASENIA |\n");
	for(i = 0;i < nusuarios;i++){
		if((strcmp(u[i].estado,"ON"))==0){
			printf(" %s - %s - %i - %i - %i - |%s| -",u[i].nick,u[i].nombre,u[i].nivel,u[i].vida,u[i].escudo,u[i].estado);
			printf(" %i - %i - %i - %s - %s\n",u[i].dinero,u[i].pjugadas,u[i].pganadas,u[i].perfil,u[i].contrasenia);
		printf(" --------------------------------------------------------------------------------------------------\n");
		}
	}
	printf("\n");
	system("pause");
	system("cls");
}

void promover_admin (usuario **u){
	char *cadena;
	do{
		lista_usuarios((*u));
		printf("Introduce nick: ");
		fgets()
	while()
}

void 