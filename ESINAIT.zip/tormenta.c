#include "tormenta.h"

void cargar_tormenta(tormenta **t){
	char cadena[100];
	char *ptr;
	char *delim="/";
	FILE *f;
	ntormentas=0;
	f=fopen("tormenta.txt","r");
	if(f==NULL)
	{
		printf("No se ha podido abrir el fichero tormenta.txt\n");
		system("pause");
	}
	else
	{
		while(fgets(cadena,100,f)!=NULL)
		{
			fixstring(cadena);
			fflush(stdin);
			*t=(tormenta* )realloc((*t),(ntormentas+1)*sizeof(tormenta));
			ntormentas++;
            ptr=strtok(cadena,delim);
			(*t)[ntormentas-1].x=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*t)[ntormentas-1].y=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*t)[ntormentas-1].diametro=atoi(ptr);
			ptr=strtok(NULL,delim);
			(*t)[ntormentas-1].tiempo=atoi(ptr);
		}
	}
	fclose(f);
}

void guardar_tormenta(tormenta *t)
{
	FILE *f;
	int i;
	f=fopen("tormenta.txt","w");
	for(i=0;i<ntormentas;i++)
	{
		fprintf(f,"%i/%i/%i/%i",t[i].x,t[i].y,t[i].diametro,t[i].tiempo);
	}
	fclose(f);
}

void generar_tormenta(tormena **t)
{
    
}